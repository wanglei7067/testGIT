create
    definer = root@localhost procedure init_data(IN do_date_string varchar(20), IN order_incr_num int,
                                                 IN user_incr_num int, IN if_truncate tinyint(1))
BEGIN  
     DECLARE user_count INT DEFAULT 0; 
     DECLARE sku_count INT DEFAULT 0; 
     DECLARE do_date VARCHAR(20) DEFAULT do_date_string;
     IF if_truncate THEN 
        TRUNCATE TABLE order_info ;
        TRUNCATE TABLE order_detail ;
        TRUNCATE TABLE user_info ;
        TRUNCATE TABLE payment_info;
     END IF;
     IF user_incr_num != 0 THEN
     CALL insert_user(do_date,user_incr_num);
     END IF;
     SELECT COUNT(*) INTO user_count FROM  user_info;
     CALL update_order(do_date);
     CALL insert_order(do_date,order_incr_num,user_count);
     CALL insert_payment(do_date);
 END;

